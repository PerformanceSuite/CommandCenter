# CommandCenter Hub — Phase 5
**Cross-Hub Federation + Registry Feed + Metrics**

## 🎯 Objective
Federate multiple CommandCenter hubs via NATS, unify registry + metrics, and enable MRKTZR to participate as a first-class tool.

## ⚙️ Setup
```bash
pnpm add -D tsx
pnpm add nats dotenv
pnpm tsx ./scripts/apply-phase5-scripts.ts
pnpm -C hub nats:up
export NATS_URL=nats://127.0.0.1:4222
pnpm -C hub federate
pnpm -C hub registry-feed &
pnpm -C hub metrics &
```
Emit test events:
```bash
pnpm -C hub test-events --project mrktzr
```
Observe:
- Federation console shows cross-hub events.
- Registry feed logs updates.
- Metrics log shows throughput stats.
