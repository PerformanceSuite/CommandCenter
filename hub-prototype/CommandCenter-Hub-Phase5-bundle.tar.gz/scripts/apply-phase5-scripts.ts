import fs from "fs";import path from "path";
const HUB_PKG = path.join(process.cwd(), "hub", "package.json");
if (!fs.existsSync(HUB_PKG)) { console.error("❌ hub/package.json not found."); process.exit(1); }
const pkg = JSON.parse(fs.readFileSync(HUB_PKG,"utf8"));
pkg.scripts = pkg.scripts || {};
const s = {
  "hub:federate":"tsx ../src/hub/federation.ts",
  "hub:registry-feed":"tsx ../src/hub/registryFeed.ts",
  "hub:metrics":"tsx ../src/hub/metrics.ts",
  "hub:demo-federation":"tsx ../scripts/demo-federation.ts",
  "hub:demo-metrics":"tsx ../scripts/demo-metrics.ts",
  "hub:demo-registry-feed":"tsx ../scripts/demo-registry-feed.ts"
};
let changed=false;for(const[k,v]of Object.entries(s)){if(pkg.scripts[k]!==v){pkg.scripts[k]=v;changed=true;}}
if(changed){fs.writeFileSync(HUB_PKG,JSON.stringify(pkg,null,2));console.log("✅ Added Phase5 scripts");}
else console.log("ℹ️ Already up to date");
