import fs from "fs";
import path from "path";
import { NatsPublisher } from "./natsAdapter.js";

const HUB_ID = process.env.HUB_ID || "hub-prototype";
const ROOT = path.resolve(process.cwd(), "..");
const REG_PATH = path.join(ROOT, "hub", "registry.json");

(async () => {
  const nats = new NatsPublisher();
  await nats.connect();
  console.log("📡 Registry feed active (hub.registry.update)");
  setInterval(() => {
    try {
      const entries = fs.existsSync(REG_PATH) ? JSON.parse(fs.readFileSync(REG_PATH, "utf8")) : [];
      const feed = { hubId: HUB_ID, timestamp: new Date().toISOString(), entries };
      nats.publish("hub.registry.update", new TextEncoder().encode(JSON.stringify(feed)));
      console.log("🔄 registry update broadcast");
    } catch (e) {
      console.error("Registry feed error:", e);
    }
  }, 15000);
})();
