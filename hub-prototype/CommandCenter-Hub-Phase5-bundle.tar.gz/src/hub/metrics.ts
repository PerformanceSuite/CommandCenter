import fs from "fs";
import path from "path";
import { mockBus } from "./mockBus.js";
import { NatsPublisher } from "./natsAdapter.js";

const ROOT = path.resolve(process.cwd(), "..");
const METRICS_PATH = path.join(ROOT, "snapshots/hub/metrics.log");
let count = 0;
let start = Date.now();

(async () => {
  const nats = new NatsPublisher();
  await nats.connect();
  console.log("📈 Metrics collector running (hub.metrics.tick)");
  mockBus.subscribe((evt) => {
    count++;
  });
  setInterval(() => {
    const elapsed = (Date.now() - start) / 1000;
    const rate = (count / elapsed).toFixed(2);
    const metric = { timestamp: new Date().toISOString(), total: count, rate };
    fs.appendFileSync(METRICS_PATH, JSON.stringify(metric) + "\n");
    nats.publish("hub.metrics.tick", new TextEncoder().encode(JSON.stringify(metric)));
    console.log("📊", metric);
  }, 10000);
})();
