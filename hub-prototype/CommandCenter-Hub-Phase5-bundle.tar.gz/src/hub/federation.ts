import { NatsPublisher } from "./natsAdapter.js";
import { mockBus } from "./mockBus.js";
import { subjectFromEvent, jsonBytes } from "./adapter.js";

const HUB_ID = process.env.HUB_ID || "hub-prototype";
(async () => {
  const nats = new NatsPublisher();
  await nats.connect();
  console.log(`🌐 Federation bridge active (mesh.hub.${HUB_ID}.*)`);

  mockBus.subscribe(async (evt) => {
    const subject = `mesh.hub.${HUB_ID}.${evt.origin.type}.${evt.origin.id}.${evt.type}`;
    const headers = {
      "hub-id": HUB_ID,
      "origin-type": evt.origin.type,
      "origin-id": evt.origin.id,
      "timestamp": evt.timestamp,
      "correlation-id": evt.correlationId
    };
    await nats.publish(subject, jsonBytes(evt), headers);
    console.log("↗️  federated", subject);
  });
})();
