import fs from "fs";
import path from "path";
import dotenv from "dotenv";
import { mockBus } from "./mockBus.js";
import { NatsPublisher } from "./natsAdapter.js";
import { subjectFromEvent, jsonBytes, HubEvent } from "./adapter.js";

dotenv.config();

const ROOT = path.resolve(process.cwd(), "..");
const EVENTS_PATH = path.join(ROOT, "snapshots", "hub", "events.log");

async function main() {
  const nats = new NatsPublisher();
  await nats.connect();

  // Publish local events to NATS
  mockBus.subscribe(async (evt) => {
    try {
      const subject = subjectFromEvent(evt);
      const headers = {
        "content-type": "application/json",
        "correlation-id": evt.correlationId,
        "event-id": evt.id,
        "timestamp": evt.timestamp,
        "origin-type": evt.origin.type,
        "origin-id": evt.origin.id
      };
      await nats.publish(subject, jsonBytes(evt), headers);
      console.log(`➡️  published ${subject}`);
    } catch (err) {
      console.error("Publish error:", err);
    }
  });

  console.log("🚉 Bridge active: mockBus -> NATS. Emit local events to publish.");
  console.log("Tip: in another terminal, run 'pnpm -C hub nats:subscribe-demo' to observe hub.>");

  // Keep process alive
  process.stdin.resume();
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
