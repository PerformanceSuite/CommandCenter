import { connect, StringCodec, headers as natsHeaders, NatsConnection, Subscription } from "nats";
import dotenv from "dotenv";

dotenv.config();

export class NatsPublisher {
  private url: string;
  private nc: NatsConnection | null = null;
  private sc = StringCodec();

  constructor(url?: string) {
    this.url = url || process.env.NATS_URL || "nats://127.0.0.1:4222";
  }

  async connect() {
    if (this.nc) return;
    this.nc = await connect({ servers: this.url });
    console.log(`✅ NATS connected: ${this.nc.getServer()} (url=${this.url})`);
  }

  async publish(subject: string, data: Uint8Array, headers?: Record<string,string>) {
    if (!this.nc) throw new Error("NATS not connected");
    const h = natsHeaders();
    if (headers) for (const [k, v] of Object.entries(headers)) h.set(k, v);
    this.nc.publish(subject, data, { headers: h });
  }

  async subscribe(subject: string, onMsg: (data: Uint8Array, headers: Record<string,string>) => void) {
    if (!this.nc) throw new Error("NATS not connected");
    const sub = this.nc.subscribe(subject);
    (async () => {
      for await (const m of sub) {
        const hdrs: Record<string,string> = {};
        if (m.headers) {
          for (const [k, v] of m.headers) hdrs[k] = v;
        }
        onMsg(m.data, hdrs);
      }
    })();
    return async () => {
      sub.unsubscribe();
    };
  }

  async close() {
    if (this.nc) {
      await this.nc.drain();
      this.nc = null;
    }
  }
}
