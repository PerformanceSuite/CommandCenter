export type EventOrigin = { type: "tool" | "project"; id: string };

export interface HubEvent {
  id: string;
  correlationId: string;
  origin: EventOrigin;
  timestamp: string;
  type: string;
  payload: any;
}

export interface MeshPublisher {
  connect(): Promise<void>;
  publish(subject: string, data: Uint8Array, headers?: Record<string,string>): Promise<void>;
  subscribe(subject: string, onMsg: (data: Uint8Array, headers: Record<string,string>) => void): Promise<() => Promise<void>>;
  close(): Promise<void>;
}

export function subjectFromEvent(evt: HubEvent) {
  // hub.<origin.type>.<origin.id>.<type>
  return `hub.${evt.origin.type}.${evt.origin.id}.${evt.type}`;
}

export function jsonBytes(obj: unknown): Uint8Array {
  return new TextEncoder().encode(JSON.stringify(obj));
}
