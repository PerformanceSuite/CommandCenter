# CommandCenter Hub — Phase 4
**Mesh-Bus Adapter + NATS Bridge**

## 🎯 Objective
Bridge the local mock-bus to a Mesh-Bus using NATS:
- Publish all local hub events to NATS with rich headers.
- (Optional) Subscribe from NATS subjects and persist to `snapshots/hub/events.log` for replay.
- Keep dependencies minimal and ESM-compatible.

## 🧩 Architecture
- Subject format: `hub.<origin.type>.<origin.id>.<type>` (e.g., `hub.project.veria.startup`)
- JSON payload: the full hub event object.
- NATS headers include: `correlation-id`, `event-id`, `timestamp`, `content-type`.

## 🚀 Quick Start (from hub-prototype root)
```bash
# 0) Ensure Phase 2-3 installed, then install deps
pnpm add -D tsx
pnpm add nats dotenv

# 1) Apply Phase 4 scripts into hub/package.json
pnpm tsx ./scripts/apply-phase4-scripts.ts

# 2) (Optional) Start local NATS via Docker
pnpm -C hub nats:up

# 3) Export NATS_URL (or copy .env.example to .env and edit)
export NATS_URL=${NATS_URL:-"nats://127.0.0.1:4222"}

# 4) Run the bridge publisher (mockBus -> NATS)
pnpm -C hub nats:bridge

# 5) In another terminal, run subscriber demo (NATS -> console + optional persistence)
pnpm -C hub nats:subscribe-demo

# 6) Emit events locally to see them on NATS
pnpm -C hub test-events
```

## 🔧 Files
- `src/hub/adapter.ts` — shared adapter interface & helpers.
- `src/hub/natsAdapter.ts` — NATS client wrapper.
- `src/hub/bridge.ts` — wiring mockBus -> NATS publish (and optional inbound).
- `scripts/nats-publish-demo.ts` — publishes a sample event to NATS.
- `scripts/nats-subscribe-demo.ts` — subscribes to `hub.>` and prints + (optionally) persists.
- `scripts/apply-phase4-scripts.ts` — idempotently adds Phase 4 scripts to `hub/package.json`.
- `scripts/nats-up.sh` & `docker-compose.nats.yaml` — one-line local NATS up (optional).
- `.env.example` — NATS connection settings.
- `schemas/nats-envelope.schema.json` — envelope metadata shape.

## 🧪 Validation
- Run `pnpm -C hub nats:bridge` and watch for: `✅ NATS connected ...`.
- Run `pnpm -C hub test-events`; observe subscriber printing subjects & headers.
- Confirm appended events (if `PERSIST_INBOUND=true`): `cat snapshots/hub/events.log | tail -n 5`.

## 🔐 Notes
- For production, configure NATS auth & TLS; headers already support passing `correlation-id` etc.
- Bridge is one-way by default (local -> NATS). Use the subscriber demo to ingest back if desired.
