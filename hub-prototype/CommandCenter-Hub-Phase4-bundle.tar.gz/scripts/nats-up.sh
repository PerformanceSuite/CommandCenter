#!/usr/bin/env bash
docker compose -f ../docker-compose.nats.yaml up -d
