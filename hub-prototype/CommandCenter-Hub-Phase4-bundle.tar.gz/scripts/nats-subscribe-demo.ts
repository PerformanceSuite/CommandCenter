import fs from "fs";
import path from "path";
import dotenv from "dotenv";
import { NatsPublisher } from "../src/hub/natsAdapter.js";

dotenv.config();

const ROOT = path.resolve(process.cwd(), "..");
const EVENTS_PATH = path.join(ROOT, "snapshots", "hub", "events.log");
const PERSIST = (process.env.PERSIST_INBOUND || "false").toLowerCase() === "true";

(async () => {
  const nats = new NatsPublisher();
  await nats.connect();

  console.log("👂 Subscribed to hub.> (Ctrl+C to exit)");
  await nats.subscribe("hub.>", (data, headers) => {
    try {
      const s = new TextDecoder().decode(data).trim();
      if (!s) return;
      const evt = JSON.parse(s);
      console.log("📥", headers["origin-type"], headers["origin-id"], headers["timestamp"], headers["event-id"]);
      if (PERSIST) {
        fs.mkdirSync(path.dirname(EVENTS_PATH), { recursive: true });
        fs.appendFileSync(EVENTS_PATH, s + "\n");
      }
    } catch (e) {
      console.error("Inbound parse error:", e);
    }
  });
})();
