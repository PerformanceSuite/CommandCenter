import { NatsPublisher } from "../src/hub/natsAdapter.js";
import { jsonBytes } from "../src/hub/adapter.js";

const evt = {
  id: "demo-event-id",
  correlationId: "demo-correlation-id",
  origin: { type: "project", id: "veria" },
  timestamp: new Date().toISOString(),
  type: "demo",
  payload: { hello: "world" },
};

(async () => {
  const nats = new NatsPublisher();
  await nats.connect();
  await nats.publish("hub.project.veria.demo", jsonBytes(evt), {
    "content-type": "application/json",
    "event-id": evt.id,
    "correlation-id": evt.correlationId,
    "timestamp": evt.timestamp
  });
  console.log("✅ Demo event published to hub.project.veria.demo");
  await nats.close();
})();
