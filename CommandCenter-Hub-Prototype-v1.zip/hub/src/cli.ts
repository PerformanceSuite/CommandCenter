import { readRegistry } from './registry.js';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT = path.resolve(__dirname, '..', '..');
const EVENTS_BASE = path.join(ROOT, 'snapshots', 'hub', 'events');

function usage() {
  console.log(`Usage:
  pnpm hub:list
  pnpm hub:open <id>
  pnpm hub:events
`);
}

async function list() {
  const reg = readRegistry();
  if (!reg.tools.length) {
    console.log('No tools found. Run: pnpm hub:refresh');
    return;
  }
  for (const t of reg.tools) {
    const web = t.endpoints?.web ? ` web=${t.endpoints.web}` : '';
    const api = t.endpoints?.api ? ` api=${t.endpoints.api}` : '';
    console.log(`${t.id}@${t.version} categories=[${t.categories.join(',')}]${web}${api}`);
  }
}

async function openTool(id: string) {
  const reg = readRegistry();
  const t = reg.tools.find(x => x.id === id);
  if (!t) { console.error(`Tool not found: ${id}`); process.exit(1); }
  const url = t.endpoints?.web || t.endpoints?.api;
  if (!url) { console.error(`Tool has no web/api endpoint: ${id}`); process.exit(1); }
  console.log(url);
}

function tailEvents() {
  const now = new Date();
  const ymd = `${now.getFullYear()}${String(now.getMonth()+1).padStart(2,'0')}${String(now.getDate()).padStart(2,'0')}`;
  const dir = path.join(EVENTS_BASE, ymd);
  if (!fs.existsSync(dir)) { console.log('No events yet.'); return; }
  const files = fs.readdirSync(dir).filter(f => f.endsWith('.jsonl')).sort();
  const latest = files[files.length - 1];
  const fp = path.join(dir, latest);
  console.log('# tailing', fp);
  const stream = fs.createReadStream(fp, { encoding: 'utf8', flags: 'a+' });
  stream.on('data', chunk => process.stdout.write(chunk));
  fs.watchFile(fp, { interval: 500 }, () => {
    const data = fs.readFileSync(fp, 'utf8');
    const lines = data.split('\n').filter(Boolean);
    process.stdout.write(lines.slice(-1)[0] + '\n');
  });
}

const cmd = process.argv[2];
if (!cmd) { usage(); process.exit(0); }
if (cmd === 'list') list();
else if (cmd === 'open') openTool(process.argv[3]);
else if (cmd === 'events') tailEvents();
else usage();
